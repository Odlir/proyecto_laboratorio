<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CarreraInteres extends Model
{
    protected $table = "carrera_interes";
}
