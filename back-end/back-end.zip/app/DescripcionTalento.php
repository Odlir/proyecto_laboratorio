<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DescripcionTalento extends Model
{
    protected $table = "descripcion_talento";
}
