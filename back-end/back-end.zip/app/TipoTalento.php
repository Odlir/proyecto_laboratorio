<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TipoTalento extends Model
{
    protected $table = "tipo_talento";
}
