<?php 

return array(

	/*
	|--------------------------------------------------------------------------
	| Paginación Líneas de lenguaje
	|--------------------------------------------------------------------------
	|
  | Las siguientes lineas de paginación son usadas para los enlaces de paginación.
  | Eres libre de cambiarlos a lo que quieras.
  | Si se te ocurre algo más emocionante, háznoslo saber.
	|
	*/

	'previous' => '&laquo; Anterior',
	'next'     => 'Siguiente &raquo;',

);